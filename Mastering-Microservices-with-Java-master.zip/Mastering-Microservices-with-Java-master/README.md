

# Mastering-Microservices-with-Java (First Edition)

[Mastering Microservices with Java] (https://www.packtpub.com/application-development/mastering-microservices-java?utm_source=github&utm_medium=repository&utm_campaign=9781785285172) by Packt Publishing

## Code testing requirements

### Chapter 2 

* Software: Netbeans with Java, Maven, Spring Boot
* Hardware: Any system with minimum 2 GB RAM
* OS: Any OS (Linux/Windows/Mac)

### Chapter 3 

* Software: Netbeans with Java
* Hardware: Any system with minimum 2 GB RAM
* OS: Any OS (Linux/Windows/Mac)

### Chapter 4 

* Software: Netbeans with Java, Maven, Spring Cloud, Eureka Server
* Hardware: Any system with minimum 2 GB RAM
* OS: Any OS (Linux/Windows/Mac)

### Chapter 5

* Software: Netbeans with Java, Maven, Spring Cloud, Eureka Server, Docker, CI/CD App
* Hardware: Any system with minimum 2 GB RAM
* OS: Any OS (Linux/Windows/Mac)


