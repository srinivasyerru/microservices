/**
 * Author:  vasou
 * Created: Dec 17, 2017
 */

INSERT INTO orders (id,coffeeName,price,customerId) VALUES ('1111','Greek','2.60','1234');
INSERT INTO orders (id,coffeeName,price,customerId) VALUES ('2222','Espresso','1.75','5678');