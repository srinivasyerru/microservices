/**
 * Author:  vasou
 * Created: Dec 14, 2017
 */

INSERT INTO customers (id, fullname, email) VALUES ('1234', 'Vasilis Souvatzis', 'vasouv@mail.com');
INSERT INTO customers (id, fullname, email) VALUES ('5678', 'Jon Doe', 'jondoe@mail.com');